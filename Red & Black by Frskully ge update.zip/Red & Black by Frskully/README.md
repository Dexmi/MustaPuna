# 07 Zuveløx (Poo)

![icon](https://i.imgur.com/e7IIL0n.png)

The official theme-pack of the 07 Zuveløx clan.

## Resizeable Mode
![ResizeableMode](https://i.imgur.com/5PVs84s.png)

## Fixed Mode
![FixedMode](https://i.imgur.com/oLmFDNv.png)